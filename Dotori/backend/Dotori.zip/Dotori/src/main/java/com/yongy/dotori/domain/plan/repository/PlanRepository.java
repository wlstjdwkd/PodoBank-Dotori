package com.yongy.dotori.domain.plan.repository;

public interface PlanRepository {
}
