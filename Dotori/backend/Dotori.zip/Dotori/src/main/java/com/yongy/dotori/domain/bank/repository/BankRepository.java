package com.yongy.dotori.domain.bank.repository;

public interface BankRepository {
}
