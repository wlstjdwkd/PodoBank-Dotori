package com.yongy.dotori.domain.purposeData.service;

public class PurposeDataServiceImpl {
}
