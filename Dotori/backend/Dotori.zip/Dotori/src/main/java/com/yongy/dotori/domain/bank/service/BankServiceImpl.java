package com.yongy.dotori.domain.bank.service;

public class BankServiceImpl {
}
