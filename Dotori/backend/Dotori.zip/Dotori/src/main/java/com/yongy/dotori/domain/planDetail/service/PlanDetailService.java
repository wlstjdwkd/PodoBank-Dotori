package com.yongy.dotori.domain.planDetail.service;

public interface PlanDetailService {
}
