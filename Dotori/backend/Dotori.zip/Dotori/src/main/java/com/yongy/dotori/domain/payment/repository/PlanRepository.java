package com.yongy.dotori.domain.payment.repository;

public interface PlanRepository {
}
