package com.yongy.dotori.domain.account.repository;

public interface AccountRepository {
}
