package com.yongy.dotori.domain.plan.entity;

public enum State {
    ACTIVE, INACTIVE, COMPLETED, SAVED
}
