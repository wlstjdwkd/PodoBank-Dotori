package com.yongy.dotori.domain.reward.service;

public interface RewardService {
}
