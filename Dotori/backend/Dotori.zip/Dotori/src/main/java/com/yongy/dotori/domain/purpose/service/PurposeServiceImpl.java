package com.yongy.dotori.domain.purpose.service;

public class PurposeServiceImpl {
}
