package com.yongy.dotori.domain.categoryGroup.service;

public interface CategoryGroupService {
}
