package com.yongy.dotori.domain.purpose.repository;

public interface PurposeRepository {
}
