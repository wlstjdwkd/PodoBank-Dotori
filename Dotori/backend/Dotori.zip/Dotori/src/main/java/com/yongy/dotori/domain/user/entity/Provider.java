package com.yongy.dotori.domain.user.entity;

public enum Provider {
    ADMIN, KAKAO, NAVER, DOTORI
}
