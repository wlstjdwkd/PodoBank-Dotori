package com.yongy.dotori.domain.planDetail.repository;

public interface PlanDetailRepository {
}
