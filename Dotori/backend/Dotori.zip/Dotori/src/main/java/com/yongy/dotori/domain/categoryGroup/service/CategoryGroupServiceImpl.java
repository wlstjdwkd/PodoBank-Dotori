package com.yongy.dotori.domain.categoryGroup.service;

public class CategoryGroupServiceImpl {
}
