package com.yongy.dotori.domain.purposeData.repository;

public interface PurposeDataRepository {
}
