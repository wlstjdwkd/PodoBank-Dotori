package com.yongy.dotori.domain.reward.service;

public class RewardServiceImpl {
}
