package com.yongy.dotori.domain.account.service;

public class AccountServiceImpl {
}
