package com.yongy.dotori.domain.category.service;

public interface CategoryService {
}
