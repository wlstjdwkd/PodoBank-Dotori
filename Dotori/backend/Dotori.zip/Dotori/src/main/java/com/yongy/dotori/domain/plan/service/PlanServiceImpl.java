package com.yongy.dotori.domain.plan.service;

public class PlanServiceImpl {
}
