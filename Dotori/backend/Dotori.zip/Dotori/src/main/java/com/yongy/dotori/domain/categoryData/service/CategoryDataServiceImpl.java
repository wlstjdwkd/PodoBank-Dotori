package com.yongy.dotori.domain.categoryData.service;

public class CategoryDataServiceImpl {
}
