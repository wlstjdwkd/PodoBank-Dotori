package com.yongy.dotori.domain.payment.service;

public interface PlanService {
}
