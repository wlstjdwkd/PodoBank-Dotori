package com.yongy.dotori.domain.categoryData.service;

public interface CategoryDataService {
}
