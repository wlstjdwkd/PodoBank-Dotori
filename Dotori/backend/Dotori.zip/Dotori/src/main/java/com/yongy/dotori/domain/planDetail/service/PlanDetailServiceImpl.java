package com.yongy.dotori.domain.planDetail.service;

public class PlanDetailServiceImpl {
}
