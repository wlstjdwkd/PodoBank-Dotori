package com.yongy.dotori.domain.reward.repository;

public interface RewardRepository {
}
