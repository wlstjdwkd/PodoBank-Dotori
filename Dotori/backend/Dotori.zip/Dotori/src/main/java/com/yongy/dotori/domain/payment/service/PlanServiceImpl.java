package com.yongy.dotori.domain.payment.service;

public class PlanServiceImpl {
}
