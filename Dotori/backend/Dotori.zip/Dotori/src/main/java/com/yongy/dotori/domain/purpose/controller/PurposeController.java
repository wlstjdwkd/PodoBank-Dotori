package com.yongy.dotori.domain.purpose.controller;

public class PurposeController {
}
