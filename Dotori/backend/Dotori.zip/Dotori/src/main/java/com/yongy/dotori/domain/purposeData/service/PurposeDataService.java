package com.yongy.dotori.domain.purposeData.service;

public interface PurposeDataService {
}
