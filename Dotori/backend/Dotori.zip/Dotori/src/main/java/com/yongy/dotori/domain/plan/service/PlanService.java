package com.yongy.dotori.domain.plan.service;

public interface PlanService {
}
