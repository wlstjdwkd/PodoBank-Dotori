package com.yongy.dotori.domain.category.service;

public class CategoryServiceImpl {
}
