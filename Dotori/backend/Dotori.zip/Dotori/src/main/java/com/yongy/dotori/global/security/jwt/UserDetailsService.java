package com.yongy.dotori.global.security.jwt;

import com.yongy.dotori.domain.user.entity.User;
import com.yongy.dotori.domain.user.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Transactional
@Service
public class UserDetailsService {
    private UserRepository userRepository;

    public User getUserInfo(String id){
        return userRepository.findUserByIdAndExpiredAtIsNull(id);
    }
}
