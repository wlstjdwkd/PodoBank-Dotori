package com.yongy.dotori.domain.user.entity;

public enum Role {
    USER, ADMIN
}

