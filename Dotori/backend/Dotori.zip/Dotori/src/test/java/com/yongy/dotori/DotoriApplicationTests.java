package com.yongy.dotori;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DotoriApplicationTests {

    @Test
    void contextLoads() {
    }

}
